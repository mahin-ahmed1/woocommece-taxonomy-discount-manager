
<?php
// If uninstall is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

// Function to delete the table when the plugin is deleted
global $wpdb;
$table_name = $wpdb->prefix . 'woo_td_discounts';
$wpdb->query("DROP TABLE IF EXISTS $table_name");
