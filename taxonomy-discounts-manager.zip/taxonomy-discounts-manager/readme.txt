=== Taxonomy Discount Manager ===
Contributors: mahin10
Tags: deals, discounts, sales, pricing, terms, taxonomy
Requires at least: 6.3
Requires PHP: 7.4
Tested up to: 6.5
Stable tag: 5.9.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Easily configure discounts and pricing rules for WooCommerce products based on any product taxonomy terms.



= Features =

Flexible Discount Rules:

* Percentage Discount: Apply an absolute percentage discount to all products within a specific taxonomy term.
* Fixed Discount: Apply a fixed amount discount to products within a specific taxonomy term.
* Apply discounts to both sale prices and regular prices seamlessly.
* use cookies.


== Screenshots ==

1. taxonomy-discount-manager.png

