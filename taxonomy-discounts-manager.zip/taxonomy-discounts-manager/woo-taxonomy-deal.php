<?php
/*
Plugin Name: Taxonomy Discounts Manager
Plugin URI: https://yourwebsite.com/woo-taxonomy-deal
Description: A WordPress plugin to apply discounts in WooCommerce based on product taxonomy.
Version: 1.0.0
Author: Mahin Ahmed
Author URI: https://yourwebsite.com
License: GPL v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: taxonomy-discounts-manager
*/

// Check if WooCommerce is active
function woo_td_check_dependencies() {
    if (!class_exists('WooCommerce')) {
        // WooCommerce is not active, deactivate the plugin
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('Sorry, but this plugin requires WooCommerce to be installed and activated.', 'taxonomy-discounts-manager') . '<br><a href="' . admin_url('plugins.php') . '">' . __('&laquo; Return to Plugins', 'taxonomy-discounts-manager') . '</a>');
    } else {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_td_discounts';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            deal_name varchar(255) NOT NULL,
            taxonomy_type varchar(50) NOT NULL,
            taxonomy_name varchar(255) NOT NULL,
            discount_amount decimal(10,2) NOT NULL,
            discount_apply_on varchar(250) NOT NULL,
            discount_type varchar(20) NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $result = dbDelta($sql);
    }
}


register_activation_hook(__FILE__, 'woo_td_check_dependencies');
register_activation_hook(__FILE__, 'woo_td_admin_styles');




function woo_td_admin_styles() {
    // Define the path to the CSS file
    $css_file = plugins_url('/admin/css/woo-td-admin.css', __FILE__);

    // Enqueue the CSS file
    $screen = get_current_screen();
    
    if (isset($screen->id) && strpos($screen->id, 'woocommerce_page_') !== false) {
        // Check if the submenu page matches your specific page
        if ($screen->id == 'woocommerce_page_woo_taxonomy_deal_settings') {
            // Define the path to the CSS file
            $css_file = plugins_url('/admin/css/woo-td-admin.css', __FILE__);
            
            // Enqueue the CSS file
            wp_enqueue_style('woo-td-admin-css', $css_file);
        }
    }
          
    

    
}
add_action('admin_enqueue_scripts', 'woo_td_admin_styles');




// Function to delete the table when the plugin is deleted
function woo_td_delete_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'woo_td_discounts';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}

register_uninstall_hook(__FILE__, 'woo_td_delete_plugin');



// Make strings translatable
function woo_td_load_textdomain() {
    load_plugin_textdomain('taxonomy-discounts-manager', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'woo_td_load_textdomain');


/// REQUIRE OPTION PAGE 
 require_once plugin_dir_path( __FILE__ ) . 'includes/woo-td-option-page.php';


// AJAX handler to fetch taxonomy names
add_action('wp_ajax_woo_td_get_taxonomy_names', 'woo_td_get_taxonomy_names_callback');

function woo_td_get_taxonomy_names_callback() {
    $taxonomy_type = isset($_POST['taxonomy_type']) ? $_POST['taxonomy_type'] : 'product_cat';
    $taxonomy_terms = get_terms(array(
        'taxonomy' => $taxonomy_type,
        'hide_empty' => false,
    ));
    wp_send_json($taxonomy_terms);
    wp_die();
}


   

// AJAX handler to delete deal
add_action('wp_ajax_woo_td_delete_deal', 'woo_td_delete_deal_callback');
function woo_td_delete_deal_callback() {
    if (isset($_POST['deal_id'])) {
        $deal_id = intval($_POST['deal_id']);
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_td_discounts';
        $result = $wpdb->delete($table_name, array('id' => $deal_id), array('%d'));
        if ($result !== false) {
            wp_send_json_success('Deal deleted successfully');
        } else {
            wp_send_json_error('Error deleting deal');
        }
    } else {
        wp_send_json_error('Invalid request');
    }
    wp_die();
}







// Function to calculate discounted price
function get_woo_td_get_calculate_discounted_price($regular_price, $discount_type, $sale_price, $discount_amount, $discount_apply_on) {
    $discounted_price = $regular_price; // Default to regular price

    if ($discount_apply_on === 'sale_price') {
        if ($discount_type == 'percent') {
            $discounted_price = max(0, $sale_price - ($sale_price * ($discount_amount / 100)));
        } elseif ($discount_type == 'fixed') {
            $discounted_price = max(0, $sale_price - $discount_amount);
        }
    } elseif ($discount_apply_on == 'regular_price') {
        if ($discount_type == 'percent') {
            $discounted_price = max(0, $regular_price - ($regular_price * ($discount_amount / 100)));
        } elseif ($discount_type == 'fixed') {
            $discounted_price = max(0, $regular_price - $discount_amount);
        }
    }

    return $discounted_price;
}


// Function to retrieve discounts and calculate discounted prices
function woo_td_get_discounted_price($product_id) {
    global $wpdb;

    // Retrieve all data from the wp_woo_td_discounts table
    $discounts = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woo_td_discounts");

    $product = wc_get_product($product_id);
    $regular_price = $product->get_regular_price();
    $sale_price = $product->get_sale_price();

    // Initialize with the regular price
    $discounted_price = $regular_price;

    // Loop through each discount
    foreach ($discounts as $discount) {
        $taxonomy_type = $discount->taxonomy_type;
        $taxonomy_name = $discount->taxonomy_name;
        $discount_amount = $discount->discount_amount;
        $discount_type = $discount->discount_type;
        $discount_apply_on = $discount->discount_apply_on;

        // Check if the product is associated with the specified category or tag
        if ($taxonomy_type === 'product_cat') {
            // Check if the product is in the specified category
            if (has_term($taxonomy_name, 'product_cat', $product_id)) {
                // Apply discount based on discount application type
                $discounted_price = get_woo_td_get_calculate_discounted_price($regular_price, $discount_type, $sale_price, $discount_amount, $discount_apply_on);
                break; // Break the loop after applying the first matching discount
            }
        } elseif ($taxonomy_type === 'product_tag') {
            // Check if the product has the specified tag
            if (has_term($taxonomy_name, 'product_tag', $product_id)) {
                // Apply discount based on discount application type
                $discounted_price =  get_woo_td_get_calculate_discounted_price($regular_price, $discount_type, $sale_price, $discount_amount, $discount_apply_on);
                break; // Break the loop after applying the first matching discount
            }
        }
    }

    return $discounted_price;
}




// Function to display discounted price on the product page
function display_discounted_price($price_html, $product) {
    $discounted_price = woo_td_get_discounted_price($product->get_id());
    $regular_price = $product->get_regular_price();
    $sale_price = $product->get_sale_price();

    // Check if discount amount is greater than zero
    if ($discounted_price < $regular_price) {
        // If discount is applied to regular price, display discounted regular price
        $discounted_price_html = wc_price($discounted_price);
        return '<del>' . wc_price($regular_price) . '</del> <ins class="woo-discounted-price">' . $discounted_price_html . '</ins>';
    } elseif ($discounted_price < $sale_price) {
        // If discount is applied to sale price, display discounted sale price
        $discounted_price_html = wc_price($discounted_price);
        return '<del>' . wc_price($sale_price) . '</del> <ins class="woo-discounted-price">' . $discounted_price_html . '</ins>';
    } else {
        // If no discount is applied, return the original price only
        return $price_html;
    }
}



// Hook the function to display discounted price on the product page
add_filter('woocommerce_get_price_html', 'display_discounted_price', 10, 2);




// Hook function to apply discounts to cart items
add_action('woocommerce_before_calculate_totals', 'woo_td_apply_discounts_to_cart_items');

function woo_td_apply_discounts_to_cart_items($cart) {
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }

    global $wpdb;

    // Retrieve all data from the wp_woo_td_discounts table
    $discounts = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woo_td_discounts");

    if (!$discounts) {
        return;
    }

    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        $product_id = $cart_item['product_id'];
        $product = wc_get_product($product_id);

        if (!$product) {
            continue;
        }

        $regular_price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();

        $discounted_price = $regular_price;

        foreach ($discounts as $discount) {
            $taxonomy_type = $discount->taxonomy_type;
            $taxonomy_name = $discount->taxonomy_name;
            $discount_amount = $discount->discount_amount;
            $discount_type = $discount->discount_type;
            $discount_apply_on = $discount->discount_apply_on;

            if ($taxonomy_type === 'product_cat') {
                if (has_term($taxonomy_name, 'product_cat', $product_id)) {
                    $discounted_price =  get_woo_td_get_calculate_discounted_price($regular_price, $discount_type, $sale_price, $discount_amount, $discount_apply_on);
                    break;
                }
            } elseif ($taxonomy_type === 'product_tag') {
                if (has_term($taxonomy_name, 'product_tag', $product_id)) {
                    $discounted_price =  get_woo_td_get_calculate_discounted_price($regular_price, $discount_type, $sale_price, $discount_amount, $discount_apply_on);
                    break;
                }
            }
        }

        $cart_item['data']->set_price($discounted_price);
    }
}





    