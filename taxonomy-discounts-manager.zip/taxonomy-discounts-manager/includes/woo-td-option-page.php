<?php 
// Add options page under WooCommerce submenu
function woo_td_add_options_page() {
    add_submenu_page(
        'woocommerce',
        __('Woo Taxonomy Deal', 'taxonomy-discounts-manager'),
        __('Woo Taxonomy Deal', 'taxonomy-discounts-manager'),
        'manage_options',
        'woo_taxonomy_deal_settings',
        'woo_td_options_page'
    );
}
add_action('admin_menu', 'woo_td_add_options_page');

// Render options page content
function woo_td_options_page() {
    ?>
    <div class="wrap">
        <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
        <form method="POST" action="">
        <?php
            // Add nonce field
            wp_nonce_field('woo_td_add_discount_nonce', 'woo_td_add_discount_nonce');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Deal Name', 'taxonomy-discounts-manager'); ?></th>
                    <td><input type="text" name="deal_name" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Taxonomy Type', 'taxonomy-discounts-manager'); ?></th>
                    <td>
                        <select name="taxonomy_type" id="taxonomy_type">
                            <option value="product_tag"><?php _e('Product Tag', 'taxonomy-discounts-manager'); ?></option>
                            <option value="product_cat" selected><?php _e('Product Category', 'taxonomy-discounts-manager'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr valign="top" id="taxonomy_name_row">
                    <th scope="row"><?php _e('Taxonomy Name', 'taxonomy-discounts-manager'); ?></th>
                    <td>
                        <select name="taxonomy_name" id="taxonomy_name">
                            <?php
                            $taxonomy_terms = get_terms(array(
                                'taxonomy' => 'product_cat',
                                'hide_empty' => false,
                            ));
                            foreach ($taxonomy_terms as $term) {
                                echo '<option value="' . esc_attr($term->slug) . '">' . esc_html($term->name) . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Discount Amount', 'taxonomy-discounts-manager'); ?></th>
                    <td>
                        <input type="text" name="discount_amount" />
                        <select name="discount_type">
                            <option value="percent"><?php _e('Percentage', 'taxonomy-discounts-manager'); ?></option>
                            <option value="fixed"><?php _e('Fixed Amount', 'taxonomy-discounts-manager'); ?></option>
                        </select>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('Discount Apply On', 'taxonomy-discounts-manager'); ?></th>
                    <td>
                        <select name="discount_apply_on" id="discount_apply_on">
                            <option value="regular_price"><?php _e('Regular Price', 'taxonomy-discounts-manager'); ?></option>
                            <option value="sale_price"><?php _e('Sale Price', 'taxonomy-discounts-manager'); ?></option>
                        </select>
                    </td>
                </tr>
                

                <!-- Add more fields as needed -->
            </table>
            <input type="hidden" name="action" value="woo_td_add_discount">
            <?php submit_button(__('Add Deal', 'taxonomy-discounts-manager')); 
            

            if (isset($_POST['submit'])) { // Check if the form is submitted
                if (isset($_POST['deal_name'], $_POST['taxonomy_type'], $_POST['taxonomy_name'], $_POST['discount_amount'])) {
                    if (isset($_POST['woo_td_add_discount_nonce']) && wp_verify_nonce($_POST['woo_td_add_discount_nonce'], 'woo_td_add_discount_nonce')) {
                        // Sanitize and validate submitted data
                        $deal_name = sanitize_text_field($_POST['deal_name']);
                        $taxonomy_type = sanitize_text_field($_POST['taxonomy_type']);
                        $taxonomy_name = sanitize_text_field($_POST['taxonomy_name']);
                        $discount_amount = floatval($_POST['discount_amount']); // Assuming discount amount is numeric
                        $discount_type = sanitize_text_field($_POST['discount_type']);
                        $discount_apply_on =sanitize_text_field($_POST['discount_apply_on']);

                        
                        // Insert data into database
                        global $wpdb;
                        $table_name = $wpdb->prefix . 'woo_td_discounts';
                        $result = $wpdb->insert(
                            $table_name,
                            array(
                                'deal_name' => $deal_name,
                                'taxonomy_type' => $taxonomy_type,
                                'taxonomy_name' => $taxonomy_name,
                                'discount_amount' => $discount_amount,
                                'discount_apply_on' => $discount_apply_on, 
                                'discount_type' => $discount_type,
                            ),
                            array(
                                '%s',
                                '%s',
                                '%s',
                                '%f',
                                '%s',
                                '%s', // Corresponding placeholder for the new field
                            )
                        );
                        
                        // Redirect after form submission to prevent resubmission on page refresh
                        if ($result !== false) {
                            wp_redirect(admin_url('admin.php?page=woo_taxonomy_deal_settings'));
                            exit;
                        } else {
                            // Handle insertion error
                            echo "Error inserting data into the database.";
                        }
                    } else {
                        _e("Nonce verification failed", 'taxonomy-discounts-manager');
                    }
                }
            }
     
            
            ?>
            
        </form>


<!-- Display saved deal data -->
<h2><?php _e('Saved Deals', 'taxonomy-discounts-manager'); ?></h2>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th><?php _e('Deal Name', 'taxonomy-discounts-manager'); ?></th>
            <th><?php _e('Taxonomy Type', 'taxonomy-discounts-manager'); ?></th>
            <th><?php _e('Taxonomy Name', 'taxonomy-discounts-manager'); ?></th>
            <th><?php _e('Discount Amount', 'taxonomy-discounts-manager'); ?></th>
            <th><?php _e('Discount Type', 'taxonomy-discounts-manager'); ?></th>
            <th><?php _e('Discount Apply On', 'taxonomy-discounts-manager'); ?></th> <!-- New column for Discount Apply On -->
            <th><?php _e('Actions', 'taxonomy-discounts-manager'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Retrieve saved deal data
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_td_discounts';
        $saved_deals = $wpdb->get_results("SELECT * FROM $table_name");

        // Display saved deal data
        foreach ($saved_deals as $deal) {
            echo '<tr>';
            echo '<td>' . esc_html($deal->deal_name) . '</td>';
            echo '<td>';
            $woo_td_taxonomy = ($deal->taxonomy_type);
            if($woo_td_taxonomy == "product_cat"){
               echo esc_html('Product Category');
            }else{
               echo esc_html('Product Tags');
            }
            echo '</td>';
            echo '<td>' . esc_html($deal->taxonomy_name) . '</td>';
            echo '<td>' . esc_html($deal->discount_amount) . '</td>';
            echo '<td>' . esc_html($deal->discount_type) . '</td>';
            echo '<td>';
            $woo_td_discount_apply = ($deal->discount_apply_on);
            if($woo_td_discount_apply == "regular_price"){
               echo esc_html('Regular Price');
            }else{
               echo esc_html('Sale Price');
            }
            echo '</td>';
            echo '<td><button class="delete-deal-button" data-deal-id="' . esc_attr($deal->id) . '">' . __('Delete', 'taxonomy-discounts-manager') . '</button></td>';
            echo '</tr>';
        }
        ?>
    </tbody>
</table>


    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Add event listener to delete buttons
            const deleteButtons = document.querySelectorAll('.delete-deal-button');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const dealId = this.getAttribute('data-deal-id');
                    if (confirm('Are you sure you want to delete this deal?')) {
                        // Perform AJAX request to delete deal
                        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: 'action=woo_td_delete_deal&deal_id=' + dealId,
                        })
                        .then(response => {
                            if (response.ok) {
                                // Reload the page after successful deletion
                                location.reload();
                            } else {
                                console.error('Error deleting deal');
                            }
                        })
                        .catch(error => console.error('Error deleting deal:', error));
                    }
                });
            });
        });
    </script>





    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const taxonomyTypeDropdown = document.getElementById('taxonomy_type');
            const taxonomyNameRow = document.getElementById('taxonomy_name_row');

            taxonomyTypeDropdown.addEventListener('change', function() {
                const selectedOption = taxonomyTypeDropdown.options[taxonomyTypeDropdown.selectedIndex].value;
                if (selectedOption === 'product_tag') {
                    fetchTaxonomyNames(selectedOption);
                } else {
                    fetchTaxonomyNames('product_cat');
                }
            });

            function fetchTaxonomyNames(taxonomyType) {
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=woo_td_get_taxonomy_names&taxonomy_type=' + taxonomyType,
                })
                .then(response => response.json())
                .then(data => {
                    const selectElement = document.getElementById('taxonomy_name');
                    selectElement.innerHTML = '';
                    data.forEach(term => {
                        const optionElement = document.createElement('option');
                        optionElement.setAttribute('value', term.slug);
                        optionElement.textContent = term.name;
                        selectElement.appendChild(optionElement);
                    });
                })
                .catch(error => console.error('Error fetching taxonomy names:', error));
            }
        });
    </script>
    <?php
}